# PulPy - Pulses in Python

## Description
TODO: this is a placeholder 

A brief description of what this project does and who it's for.

## Installation
TODO: this is a placeholder

Provide step by step series of examples and explanations about how to get a development environment running.

```bash
git clone <repository>
cd <repository>
npm install